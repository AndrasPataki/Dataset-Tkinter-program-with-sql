from tkinter import ttk
from tkinter import *
import tkinter
import sqlite3

#Programa feito por András Pataki. Acompanhe a descrição do código. Banco de dados esta com 2 campos; ID e Name. 

class Description:
 
    # propriedade do dir de conexão------------------------------------------------
    db_name = 'database.db'

    def __init__(self, window):
        
        #Inicializações --------------------------------------------------
        self.wind = window
        self.wind.title('Description DataSet')

        
        #Criando um Contêiner de Quadro-------------------------------------------
        frame = LabelFrame(self.wind, text = 'Registrar novas descrições')
        frame.grid(row = 0, column = 0, columnspan = 3, pady = 20)        
        
        # Name Input------------------------------------------------------
        Label(frame, text = 'Name: ').grid(row = 1, column = 0)
        self.name = Text(frame)
        self.name.focus()
        self.name.grid(row = 1, column = 1)


        # Button Add Descrições --------------------------------------------------
        ttk.Button(frame, text = 'Salvar Description', command = self.add_description).grid(row = 2, columnspan = 2, sticky = W + E)

        
        # Mensagens de Saída ---------------------------------------------------
        self.message = Label(text = '', fg = 'red')
        self.message.grid(row = 5, column = 0, columnspan = 3, sticky = W + E)
      
       

   
    # Função para executar bancos de dados --------------------------------------------
    def run_query(self, query, parameters = ()):
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            result = cursor.execute(query, parameters)
            conn.commit()
        return result

       
        # recebendo dados----------------------------------------------------------------
        query = 'SELECT * FROM description ORDER BY name DESC'
        db_rows = self.run_query(query)
        
      
        # preenchendo dados-----------------------------------------------------------
        for row in db_rows:
            self.tree.insert('', 0, text = row[1], values = row[1])

    
    # Validação De Entrada De Usuário -----------------------------------------------------
    def validation(self):
        return len(self.name.get(1.0, END))

    def add_description(self):
        if self.validation():
            query = 'INSERT INTO description VALUES(NULL, ?)'
            parameters =  (self.name.get(1.0,tkinter.END),)
            self.run_query(query, parameters)
            self.message['text'] = 'Descrição {} adicionada com Sucesso!'.format(self.name.get(1.0, END))
            self.name.delete(1.0, END)


 
        else:
            self.message['text'] = 'Nome Obrigatório'
    

if __name__ == '__main__':
    window = Tk()
    application = Description(window)
    window.mainloop()
